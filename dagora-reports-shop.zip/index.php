<?php 
 /**
  * The base template
  * */

get_header( 'vue-custom' ); ?>



<?php get_footer( 'vue-custom' ); ?>