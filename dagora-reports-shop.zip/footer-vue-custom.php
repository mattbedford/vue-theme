
<?php

echo "</body></html>";
wp_footer();
